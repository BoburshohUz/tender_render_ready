class TenderAdapter:
    def upload(self, file_path: str) -> dict:
        # placeholder implementation
        return {"status":"uploaded","file":file_path}
